var searchData=
[
  ['minimumserial_2eh',['MinimumSerial.h',['../_minimum_serial_8h.html',1,'']]]
];
